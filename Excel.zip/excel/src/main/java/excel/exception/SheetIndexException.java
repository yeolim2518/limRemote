package excel.exception;

public class SheetIndexException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public SheetIndexException(String msg) {
		super(msg);
	}
}
